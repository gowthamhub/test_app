package com.uob.edag;

import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.client.solrj.response.UpdateResponse;
import org.apache.solr.common.SolrInputDocument;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class HiveToSolr {
    private String jdbcUrl;
    private String jdbcDriver;
    private String solrUrl;
    private String solrCollection;

    public HiveToSolr(String jdbcUrl, String jdbcDriver, String solrUrl, String solrCollection) {
        this.jdbcUrl = jdbcUrl;
        this.jdbcDriver = jdbcDriver;
        this.solrUrl = solrUrl;
        this.solrCollection = solrCollection;
    }

    // Fetch data from Hive
    public List<SolrInputDocument> fetchHiveData(String query) {
        List<SolrInputDocument> documents = new ArrayList<>();
        try {
            // Load Hive JDBC driver
            Class.forName(jdbcDriver);

            // Connect to Hive
            Connection connection = DriverManager.getConnection(jdbcUrl);
            Statement statement = connection.createStatement();

            // Execute query
            ResultSet resultSet = statement.executeQuery(query);
            int columnCount = resultSet.getMetaData().getColumnCount();

            // Convert result to SolrInputDocuments
            while (resultSet.next()) {
                SolrInputDocument document = new SolrInputDocument();
                for (int i = 1; i <= columnCount; i++) {
                    String columnName = resultSet.getMetaData().getColumnName(i);
                    Object columnValue = resultSet.getObject(i);
                    document.addField(columnName, columnValue);
                }
                documents.add(document);
            }

            resultSet.close();
            statement.close();
            connection.close();
        } catch (Exception e) {
            System.err.println("Error fetching data from Hive: " + e.getMessage());
        }
        return documents;
    }

    // Push data to Solr
    public void pushToSolr(List<SolrInputDocument> documents) {
        try {
            // Create Solr client
            SolrClient solrClient = new HttpSolrClient.Builder(solrUrl + "/" + solrCollection).build();

            // Add documents to Solr
            UpdateResponse response = solrClient.add(documents);
            solrClient.commit();

            System.out.println("Data successfully pushed to Solr collection: " + solrCollection);
            System.out.println("Solr Response: " + response);
        } catch (Exception e) {
            System.err.println("Error pushing data to Solr: " + e.getMessage());
        }
    }

    // Process data from Hive to Solr
    public void process(String hiveQuery) {
        // Fetch data from Hive
        List<SolrInputDocument> hiveData = fetchHiveData(hiveQuery);
        if (hiveData != null && !hiveData.isEmpty()) {
            System.out.println("Fetched " + hiveData.size() + " rows from Hive.");
            // Push data to Solr
            pushToSolr(hiveData);
        } else {
            System.out.println("No data fetched from Hive. Process terminated.");
        }
    }

    public static void main(String[] args) {
        try {
            // Load configuration from property files
            Properties jdbcProps = new Properties();
            jdbcProps.load(new FileInputStream("./jdbc.properties")); // Replace with your Linux path

            Properties solrProps = new Properties();
            solrProps.load(new FileInputStream("./solr.properties")); // Replace with your Linux path

            Properties queryProps = new Properties();
            queryProps.load(new FileInputStream("./query.properties")); // Replace with your Linux path

            // Read properties
            String JDBC_URL = jdbcProps.getProperty("jdbc_url");
            String JDBC_DRIVER = jdbcProps.getProperty("jdbc_driver");
            String SOLR_URL = solrProps.getProperty("solr_url");
            String SOLR_COLLECTION = solrProps.getProperty("solr_collection");
            String HIVE_QUERY = queryProps.getProperty("hive_query");

            // Initialize and process
            HiveToSolr hiveToSolr = new HiveToSolr(JDBC_URL, JDBC_DRIVER, SOLR_URL, SOLR_COLLECTION);
            hiveToSolr.process(HIVE_QUERY);
        } catch (IOException e) {
            System.err.println("Error loading property files: " + e.getMessage());
        }
    }
}




//jdbc_url=jdbc:hive2://lxedatsg0m02.sg.uobnet.com:2181,lxedatsg0m04.sg.uobnet.com:2181/default;serviceDiscoveryMode=zookeeper;ssl=true;sslTrustStore=/var/lib/cloudera-scm-agent/agent-cert/cm-auto-global_truststore.jks;trustStorePassword=<truststore_password>;trustStoreType=jks;zooKeeperNamespace=hiveserver2
//jdbc_driver=org.apache.hive.jdbc.HiveDriver
//
//
//
//
//
//        solr_url=http://localhost:8983/solr
//solr_collection=your_solr_collection
//
//
//
//
//        hive_query=SELECT * FROM your_hive_table